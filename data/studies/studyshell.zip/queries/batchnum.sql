SELECT AssayList.Name,
AssayList.Description,
AssayList.Type,
AssayList.Created,
AssayList.CreatedBy,
AssayList.Modified,
AssayList.ModifiedBy,
AssayList.LSID
FROM AssayList
