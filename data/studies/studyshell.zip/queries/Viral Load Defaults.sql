SELECT "Viral Load".lsid,
"Viral Load".RunDefPrimary,
"Viral Load".Primary,
"Viral Load".RunDefAdditive,
"Viral Load".Additive,
"Viral Load".RunDefDerivtiv,
"Viral Load".Derivtiv,
"Viral Load".RunDefPrepType,
"Viral Load".PrepType
FROM "Viral Load"
