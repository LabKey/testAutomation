SELECT DataInputs.Data,
DataInputs.Role
FROM DataInputs
