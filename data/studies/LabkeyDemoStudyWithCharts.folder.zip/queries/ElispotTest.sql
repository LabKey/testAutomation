SELECT ELISpotAssay.ParticipantId,
ELISpotAssay.SampleDescription,
ELISpotAssay.SpecimenID,
ELISpotAssay.SpotCount,
ELISpotAssay.WellgroupLocation,
ELISpotAssay.WellgroupName
FROM ELISpotAssay
