SELECT Demographics.ParticipantId,
Demographics.date,
Demographics.StartDate,
Demographics.Height,
Demographics.Gender,
Demographics.Country,
Demographics."Group",
Demographics.Status,
Demographics.Comments
FROM Demographics
