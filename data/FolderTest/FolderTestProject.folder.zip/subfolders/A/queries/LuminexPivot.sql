SELECT
  ParticipantId,
  AnalyteName,
  COUNT(ParticipantId) AS ParticipantCount,
  MIN(ConcInRange) AS ConcInRange_MIN,
  AVG(ConcInRange) AS ConcInRange_AVG,
  SUM(ConcInRange) AS ConcInRange_SUM,
  GROUP_CONCAT(ConcInRange) AS ConcInRange_CONCAT
FROM LuminexAssay
GROUP BY ParticipantId, AnalyteName
PIVOT
  ConcInRange_MIN,
  ConcInRange_AVG,
  ConcInRange_SUM,
  ConcInRange_CONCAT
BY AnalyteName
